﻿namespace Core_CodeFirst.Data
{
    public class Class1
    {

    }
}