﻿namespace Core_CodeFirst.Models
{
    public class EmployeeDTO
    {
        public int Id { get; set; }

        //public string Name { get; set; } = null!;

        public string? Address { get; set; }

        public string? AddressNew { get; set; }
    }
}
