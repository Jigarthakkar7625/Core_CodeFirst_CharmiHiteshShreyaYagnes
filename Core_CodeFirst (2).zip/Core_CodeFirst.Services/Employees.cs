﻿using Core_CodeFirst.Data.Models;
using Core_CodeFirst.Services.IServices;

namespace Core_CodeFirst.Services
{
    public class Employees : ITransient, IScoped, ISingleton
    {
        //private readonly TestDbmajwtContext testDbmajwtContext;
        
        Guid id;
        //public Employees(TestDbmajwtContext db)
        public Employees()
        {
            id = Guid.NewGuid();
            //this.testDbmajwtContext = db;
        }
        //public List<Employee> GetAllEmployee()
        //{

        //    return testDbmajwtContext.Employees.ToList();
        //}

        public Guid GetOperationID()
        {
            return id;
        }
    }
}